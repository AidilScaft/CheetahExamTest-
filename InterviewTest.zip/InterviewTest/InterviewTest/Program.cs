﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace InterviewTest
{
    class Program
    {
        public static void Main(string[] args)
        {

            
            Console.WriteLine("Aidil's Interview Test");
            LoadJson();

      


     

        }

        public static void LoadJson()
        {

            try
            {
                var myJsonString = File.ReadAllText("data.json");
                var myJObject = JObject.Parse(myJsonString);
                int i = 0;
                do
                {
                    var Name1 = string.Concat((string)myJObject["recipients"][i]["name"]);

                    var ID1 = string.Concat((string)myJObject["recipients"][i]["id"]);

                    var Tags1 = ((string)myJObject["recipients"][i]["tags"].ToString()).Trim();

                    var Name2 = string.Concat((string)myJObject["recipients"][i + 1]["name"]);

                    var ID2 = string.Concat((string)myJObject["recipients"][i + 1]["id"]);

                    var Tags2 = ((string)myJObject["recipients"][i + 1]["tags"].ToString()).Trim();
                    i++;

                    //if (Enumerable.SequenceEqual(Tags1.OrderBy(e => e), Tags2.OrderBy(e => e)))
                    if (Tags1.All(Tags2.Contains))
                    {
                        Console.WriteLine(Name1 + "and " + Name2 + " have the following tags respectively");

                    }
                    else
                    {
                        Console.WriteLine("Because they only share one tag the pair " + Name1 + "," + Name2 + " should not appear on the list.");
                    }


                } while (i < 18);
            }
            catch(Exception gg)
            {
                Console.WriteLine("Error : "+gg);
            }



        }

    }
    }


